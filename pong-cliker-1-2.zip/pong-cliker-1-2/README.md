# pong cliker 1.2

A Pen created on CodePen.

Original URL: [https://codepen.io/Alejandro-Garc-a-the-solid/pen/QwNXqbW](https://codepen.io/Alejandro-Garc-a-the-solid/pen/QwNXqbW).

