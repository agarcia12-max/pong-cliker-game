document.addEventListener("DOMContentLoaded", () => {
  let puntos = 0;
  let clicValor = 1;
  let puntosPorSegundo = 0;
  let pongDesbloqueado = false;
  let snakeDesbloqueado = false;
  let musicaComprada = false;
  let hackUsado = false; 
  // --- VARIABLES DE PRESTIGIO ---
  let fichasPong = 0;
  let multiplicadorClic = 1.0;
  let multiplicadorAuto = 1.0;
  // ------------------------------

  const elPuntos = document.getElementById("puntos");
  const elFichasPong = document.getElementById("fichasPongDisplay");
  const elPPC = document.getElementById("puntosPorClicDisplay");
  const elPPS = document.getElementById("puntosPorSegundoDisplay");
  const elTienda = document.getElementById("tienda-items");
  const elLogros = document.getElementById("logros");
  const titulo = document.querySelector("h1");
  const textoFinal = document.getElementById("texto-final");
  const audioFondo = document.getElementById("musicaFondo");
  const elBoton = document.getElementById("boton"); 
  const elResetTotal = document.getElementById("reset-total-btn"); 
  let musicaIniciada = false;

  const elPrestigioPanel = document.getElementById("prestigio-panel");
  const elBotonPrestigio = document.getElementById("boton-prestigio");
  const elFichasDisponibles = document.getElementById("fichasDisponibles");
  const elTiendaPrestigio = document.getElementById("tienda-prestigio");

  const audioSecreto = new Audio("https://www.dropbox.com/scl/fi/l93r5ipgew399iiu1m12l/jazz-lounge-relaxing-background-music-412597-1.mp3?rlkey=0x8rio87pjx683i6zfi2iptvz&dl=1");
  audioSecreto.loop = true;
  audioSecreto.volume = 0.5;

  // MEJORAS REGULARES (se reinician) - Costos base en 10
  const mejoras = [
    { id: "snake", nombre: "Desbloquear Mini-Snake", costoBase: 10, nivel: 0, unico: true, accion: () => { snakeDesbloqueado = true; document.getElementById("snake-area").style.display = "block"; mostrarLogro("¡Snake desbloqueado!"); } },
    { id: "clic1", nombre: "Dedo Entrenado (+1 clic)", costoBase: 10, nivel: 0, escalado: 1.5, unico: false, accion: () => clicValor += 1 },
    { id: "clic5", nombre: "Martillo Clickeador (+5 clic)", costoBase: 10, nivel: 0, escalado: 1.8, unico: false, accion: () => clicValor += 5 },
    { id: "auto", nombre: "Robot Clicker (+1 auto/s)", costoBase: 10, nivel: 0, escalado: 1.4, unico: false, accion: () => puntosPorSegundo += 1 },
    { id: "pong", nombre: "Desbloquear Mini-Pong", costoBase: 10, nivel: 0, unico: true, accion: () => { pongDesbloqueado = true; document.getElementById("pong-area").style.display = "block"; mostrarLogro("¡Pong desbloqueado!"); } },
    { id: "musica", nombre: "Ritmo Secreto (J. Pork)", costoBase: 10, nivel: 0, unico: true, accion: () => { musicaComprada = true; renderizarMusicaComprada(); mostrarLogro("¡Ritmo secreto comprado!"); } },
  ];

  // MEJORAS DE PRESTIGIO (permanentes)
  const mejorasPrestigio = [
    { id: "mult_clic", nombre: "Multiplicador de Clic (+0.1x)", costoBase: 1, nivel: 0, escalado: 1.5, accion: () => multiplicadorClic += 0.1 },
    { id: "mult_auto", nombre: "Multiplicador Auto (+0.1x)", costoBase: 5, nivel: 0, escalado: 2, accion: () => multiplicadorAuto += 0.1 },
  ];


  function calcularFichasDisponibles() {
    const costoBase = 10000;
    const fichas = Math.floor(Math.sqrt(puntos / costoBase));
    return Math.max(0, fichas);
  }

  function reiniciarJuego() {
    const fichasGanadas = calcularFichasDisponibles();
    if (fichasGanadas === 0) return;

    // TRANSFERENCIA DE PROGRESO
    fichasPong += fichasGanadas;

    // RESETEAR VARIABLES REINICIABLES
    puntos = 0;
    clicValor = 1;
    puntosPorSegundo = 0;
    hackUsado = false;

    // RESETEAR MEJORAS NO PERMANENTES
    mejoras.forEach(m => {
        if (!m.unico) { 
            m.nivel = 0;
        } else {
            if(m.id === "snake" && snakeDesbloqueado) document.getElementById("snake-area").style.display = "block";
            if(m.id === "pong" && pongDesbloqueado) document.getElementById("pong-area").style.display = "block";
        }
    });

    // REAPLICAR MULTIPLICADORES PERMANENTES
    multiplicadorClic = 1.0;
    multiplicadorAuto = 1.0;
    mejorasPrestigio.forEach(m => {
        for(let i=0; i < m.nivel; i++) m.accion();
    });

    mostrarLogro(`¡PRESTIGIO! Ganaste ${fichasGanadas} Fichas Pong.`);
    guardar();
    actualizar();
    renderizarTienda();
    renderizarTiendaPrestigio();
  }

  function empezarDesdeCero() {
      if (!confirm("ADVERTENCIA: ¿Estás seguro de que quieres ELIMINAR todo tu progreso, incluyendo Fichas Pong y mejoras? Esta acción es irreversible.")) {
          return;
      }

      localStorage.removeItem("pongClickerSave");

      // Reset all global variables
      puntos = 0;
      clicValor = 1;
      puntosPorSegundo = 0;
      pongDesbloqueado = false;
      snakeDesbloqueado = false;
      musicaComprada = false;
      hackUsado = false;
      fichasPong = 0;
      multiplicadorClic = 1.0;
      multiplicadorAuto = 1.0;
      
      // Reset all improvements levels
      mejoras.forEach(m => m.nivel = 0);
      mejorasPrestigio.forEach(m => m.nivel = 0);

      // Hide mini-games
      document.getElementById("pong-area").style.display = "none";
      document.getElementById("snake-area").style.display = "none";
      document.getElementById("music-secret-container").innerHTML = '';
      
      mostrarLogro("Juego Reiniciado. ¡A empezar de nuevo!");
      actualizar();
  }
  elResetTotal.onclick = empezarDesdeCero;


  function guardar() {
    const save = {
      puntos, clicValor, puntosPorSegundo,
      mejoras: mejoras.map(m => ({id: m.id, nivel: m.nivel})),
      mejorasPrestigio: mejorasPrestigio.map(m => ({id: m.id, nivel: m.nivel})),
      pongDesbloqueado, snakeDesbloqueado, musicaComprada, hackUsado,
      fichasPong, multiplicadorClic, multiplicadorAuto
    };
    localStorage.setItem("pongClickerSave", JSON.stringify(save));
  }

  function cargar() {
    const data = localStorage.getItem("pongClickerSave");
    if (!data) {
        elPrestigioPanel.style.display = "block";
        return;
    }
    const s = JSON.parse(data);
    puntos = s.puntos || 0;
    hackUsado = s.hackUsado || false;

    fichasPong = s.fichasPong || 0;
    multiplicadorClic = 1.0;
    multiplicadorAuto = 1.0;

    // 1. Aplicar mejoras de prestigio
    s.mejorasPrestigio?.forEach(sm => {
        const m = mejorasPrestigio.find(m2 => m2.id === sm.id);
        if (m) {
            for (let i = 0; i < sm.nivel; i++) m.accion();
            m.nivel = sm.nivel;
        }
    });

    // 2. Cargar los valores totales de clic y auto (ya están correctos en el guardado)
    clicValor = s.clicValor || 1;
    puntosPorSegundo = s.puntosPorSegundo || 0;

    // 3. Restaurar niveles de mejoras regulares y correr acciones solo para únicas persistentes
    s.mejoras?.forEach(sm => {
      const m = mejoras.find(m2 => m2.id === sm.id);
      if (m) {
        if (m.unico) {
            if (sm.nivel > 0) m.accion();
        } 
        m.nivel = sm.nivel;
      }
    });

    pongDesbloqueado = s.pongDesbloqueado || false;
    snakeDesbloqueado = s.snakeDesbloqueado || false;
    musicaComprada = s.musicaComprada || false;

    if (pongDesbloqueado) document.getElementById("pong-area").style.display = "block";
    if (snakeDesbloqueado) document.getElementById("snake-area").style.display = "block";
    if (musicaComprada) renderizarMusicaComprada();

    elPrestigioPanel.style.display = "block";
    actualizar();
  }

  setInterval(guardar, 5000);

  function actualizar() {
    const ppcDisplay = Math.floor(clicValor * multiplicadorClic);
    const ppsDisplay = Math.floor(puntosPorSegundo * multiplicadorAuto);

    elPuntos.textContent = Math.floor(puntos);
    elFichasPong.textContent = fichasPong;
    elPPC.textContent = ppcDisplay;
    elPPS.textContent = ppsDisplay;

    const fichasDisp = calcularFichasDisponibles();
    elFichasDisponibles.textContent = fichasDisp;
    
    // Lógica del botón de Prestigio (CORREGIDA)
    const puntosNecesariosParaUno = 10000;
    
    if (fichasDisp > 0) {
        // Opción 1: Puedes hacer Prestigio
        elBotonPrestigio.textContent = `Reiniciar y Ganar ${fichasDisp} Fichas`;
        elBotonPrestigio.disabled = false; 
    } else {
        // Opción 2: No puedes hacer Prestigio
        elBotonPrestigio.disabled = true;
        const puntosFaltantes = Math.max(0, puntosNecesariosParaUno - puntos);
        
        elBotonPrestigio.textContent = `Necesitas ${Math.floor(puntosFaltantes).toLocaleString()} pts más (Total: ${puntosNecesariosParaUno.toLocaleString()}) para Renacer`;
    }

    renderizarTienda();
    renderizarTiendaPrestigio();
  }

  function renderizarTienda(lista = mejoras, contenedor = elTienda) {
    contenedor.innerHTML = "";
    const esPrestigio = lista === mejorasPrestigio;
    const moneda = esPrestigio ? fichasPong : puntos;
    const monedaSimbolo = esPrestigio ? "Fichas" : "pts";

    lista.forEach(m => {
      const precio = Math.floor(m.costoBase * Math.pow(m.escalado || 1, m.nivel));
      const item = document.createElement("div");
      item.className = "item";
      item.innerHTML = `<p>${m.nombre} ${m.unico ? "" : `(Nv. ${m.nivel})`}</p>`;
      const btn = document.createElement("button");
      btn.className = "comprar";

      if (m.unico && m.nivel > 0) {
        btn.textContent = "Desbloqueado";
        btn.disabled = true;
        btn.classList.add("desbloqueado");
      } else {
        btn.textContent = `${precio} ${monedaSimbolo}`;
        btn.disabled = moneda < precio;

        if (!btn.disabled) {
            btn.classList.add("disponible");
        }

        btn.onclick = () => {
          if (esPrestigio) {
            fichasPong -= precio;
          } else {
            puntos -= precio;
          }
          m.nivel++;
          m.accion();
          actualizar();
          guardar();
        };
      }
      item.appendChild(btn);
      contenedor.appendChild(item);
    });
  }

  function renderizarTiendaPrestigio() {
      renderizarTienda(mejorasPrestigio, elTiendaPrestigio);
  }

  function mostrarLogro(texto) {
    elLogros.textContent = texto;
    clearTimeout(elLogros.timer);
    elLogros.timer = setTimeout(() => elLogros.textContent = "", 4000);
  }

  function crearFlotante(x, y, texto) {
    const f = document.createElement("div");
    f.className = "floating";
    f.textContent = texto;
    f.style.left = `${x - 20}px`;
    f.style.top = `${y - 30}px`;
    document.body.appendChild(f);
    setTimeout(() => f.remove(), 1000);
  }

  elBoton.addEventListener("click", e => {
    if (!musicaIniciada) {
      audioFondo.volume = 0.2;
      audioFondo.play().catch(() => {});
      musicaIniciada = true;
    }
    const valorGanado = Math.floor(clicValor * multiplicadorClic);
    puntos += valorGanado;
    crearFlotante(e.clientX, e.clientY, `+${valorGanado}`);
    actualizar();
  });

  setInterval(() => {
    const ppsGanados = Math.floor(puntosPorSegundo * multiplicadorAuto);
    if (ppsGanados > 0) {
      puntos += ppsGanados;
      actualizar();
    }
  }, 1000);

  elBotonPrestigio.onclick = reiniciarJuego;


  // Lógica de los mini-juegos (Pong y Snake)
  const canvasPong = document.getElementById("pongCanvas");
  const ctxPong = canvasPong ? canvasPong.getContext("2d") : null;
  const btnPong = document.getElementById("iniciarPong");

  let juegoPong = false;
  let pelota = {x: 200, y: 100, vx: 4, vy: 3, r: 8};
  let jugadorY = 70;
  let iaY = 70;
  const palaH = 60, palaW = 12;

  function loopPong() {
    if (!juegoPong || !ctxPong) return;

    ctxPong.fillStyle = "#000";
    ctxPong.fillRect(0, 0, 400, 200);

    ctxPong.fillStyle = "#fff";
    ctxPong.beginPath();
    ctxPong.arc(pelota.x, pelota.y, pelota.r, 0, Math.PI*2);
    ctxPong.fill();

    ctxPong.fillStyle = "#0f0";
    ctxPong.fillRect(380, jugadorY, palaW, palaH);
    ctxPong.fillStyle = "#f00";
    ctxPong.fillRect(8, iaY, palaW, palaH);

    pelota.x += pelota.vx;
    pelota.y += pelota.vy;

    if (pelota.y <= 10 || pelota.y >= 190) pelota.vy *= -1;

    if (pelota.x >= 370 && pelota.y >= jugadorY && pelota.y <= jugadorY + palaH) pelota.vx = -Math.abs(pelota.vx) * 1.05;
    if (pelota.x <= 20 && pelota.y >= iaY && pelota.y <= iaY + palaH) pelota.vx = Math.abs(pelota.vx) * 1.05;

    const iaSpeed = 3.5;
    if (iaY + palaH/2 < pelota.y) iaY = Math.min(200 - palaH, iaY + iaSpeed);
    if (iaY + palaH/2 > pelota.y) iaY = Math.max(0, iaY - iaSpeed);

    if (pelota.x < 0) {
      puntos += 300;
      mostrarLogro("¡Victoria en Pong! +300 puntos");
      juegoPong = false;
      btnPong.textContent = "Jugar de nuevo";
      actualizar();
      guardar();
    } else if (pelota.x > 400) {
      mostrarLogro("Derrota... 0 puntos");
      juegoPong = false;
      btnPong.textContent = "Jugar de nuevo";
    }

    requestAnimationFrame(loopPong);
  }

  if (canvasPong) {
    canvasPong.addEventListener("mousemove", e => {
      const rect = canvasPong.getBoundingClientRect();
      jugadorY = e.clientY - rect.top - palaH/2;
      jugadorY = Math.max(0, Math.min(jugadorY, 200 - palaH));
    });
  }

  if (btnPong) {
    btnPong.addEventListener("click", () => {
      juegoPong = true;
      pelota = {x: 200, y: 100, vx: Math.random() > 0.5 ? 4 : -4, vy: (Math.random()-0.5)*6, r: 8};
      btnPong.textContent = "Jugando...";
      loopPong();
    });
  }

  const snakeCanvas = document.getElementById("snakeCanvas");
  const snakeCtx = snakeCanvas ? snakeCanvas.getContext("2d") : null;
  const btnSnake = document.getElementById("iniciarSnake");
  const snakeScoreDisplay = document.getElementById("snakeScoreDisplay");

  const grid = 16;
  const framesPerMove = 8;
  let count = 0;
  let snakeGame = {
    activo: false,
    score: 0,
    snake: { x: 160, y: 160, dx: grid, dy: 0, cells: [], maxCells: 4 },
    apple: { x: 80, y: 80 }
  };

  function resetSnake() {
    snakeGame.snake = { x: 160, y: 160, dx: grid, dy: 0, cells: [], maxCells: 4 };
    snakeGame.score = 0;
    snakeGame.apple = { x: Math.floor(Math.random()*19)*grid, y: Math.floor(Math.random()*19)*grid };
    snakeScoreDisplay.textContent = 0;
  }

  function loopSnake() {
    if (!snakeGame.activo || !snakeCtx) return;
    
    if (++count < framesPerMove) { requestAnimationFrame(loopSnake); return; }
    count = 0;

    snakeCtx.clearRect(0, 0, snakeCanvas.width, snakeCanvas.height);

    snakeGame.snake.x += snakeGame.snake.dx;
    snakeGame.snake.y += snakeGame.snake.dy;

    if (snakeGame.snake.x < 0) snakeGame.snake.x = snakeCanvas.width - grid;
    if (snakeGame.snake.x >= snakeCanvas.width) snakeGame.snake.x = 0;
    if (snakeGame.snake.y < 0) snakeGame.snake.y = snakeCanvas.height - grid;
    if (snakeGame.snake.y >= snakeCanvas.height) snakeGame.snake.y = 0;

    snakeGame.snake.cells.unshift({x: snakeGame.snake.x, y: snakeGame.snake.y});
    if (snakeGame.snake.cells.length > snakeGame.snake.maxCells) snakeGame.snake.pop();

    snakeCtx.fillStyle = "red";
    snakeCtx.fillRect(snakeGame.apple.x, snakeGame.apple.y, grid-1, grid-1);

    snakeCtx.fillStyle = "lime";
    snakeGame.snake.cells.forEach((cell, index) => {
      snakeCtx.fillRect(cell.x, cell.y, grid-1, grid-1);

      if (cell.x === snakeGame.apple.x && cell.y === snakeGame.apple.y) {
        snakeGame.snake.maxCells++;
        snakeGame.score++;
        snakeScoreDisplay.textContent = snakeGame.score;
        do {
            snakeGame.apple = { x: Math.floor(Math.random()*19)*grid, y: Math.floor(Math.random()*19)*grid };
        } while (snakeGame.snake.cells.some(c => c.x === snakeGame.apple.x && c.y === snakeGame.apple.y));
      }

      for (let i = index + 1; i < snakeGame.snake.cells.length; i++) {
        if (cell.x === snakeGame.snake.cells[i].x && cell.y === snakeGame.snake.cells[i].y) {
          const bonus = snakeGame.score * 50;
          puntos += bonus;
          actualizar();
          guardar();
          mostrarLogro(`¡Snake terminado! +${bonus} puntos (${snakeGame.score} manzanas)`);
          snakeGame.activo = false;
          btnSnake.textContent = "Jugar de nuevo";
          btnSnake.disabled = false;
        }
      }
    });

    requestAnimationFrame(loopSnake);
  }

  if (btnSnake) {
    btnSnake.addEventListener("click", () => {
      snakeGame.activo = true;
      btnSnake.disabled = true;
      btnSnake.textContent = "Jugando...";
      resetSnake();
      loopSnake();
    });
  }

  document.addEventListener("keydown", e => {
    if (!snakeGame.activo) return;
    if (e.key === "ArrowLeft" && snakeGame.snake.dx === 0) { snakeGame.snake.dx = -grid; snakeGame.snake.dy = 0; }
    else if (e.key === "ArrowUp" && snakeGame.snake.dy === 0) { snakeGame.snake.dy = -grid; snakeGame.snake.dx = 0; }
    else if (e.key === "ArrowRight" && snakeGame.snake.dx === 0) { snakeGame.snake.dx = grid; snakeGame.snake.dy = 0; }
    else if (e.key === "ArrowDown" && snakeGame.snake.dy === 0) { snakeGame.snake.dy = grid; snakeGame.snake.dx = 0; }
  });

  function renderizarMusicaComprada() {
    if (!musicaComprada) return;
    const cont = document.getElementById("music-secret-container");
    cont.innerHTML = `
      <img src="https://dl.dropboxusercontent.com/scl/fi/gfgm8n3hxgbtw2qj6s8eg/jhon-pork.jpeg?rlkey=xuexx2n4h76cuxs5qabtceay1&dl=1" style="width:150px; border-radius:10px;">
      <p id="music-status" style="cursor:pointer;">▶️ Reproducir ritmo</p>
    `;
    document.getElementById("music-status").onclick = () => {
      if (audioSecreto.paused) {
        audioSecreto.play();
        document.getElementById("music-status").textContent = "⏸️ Pausar ritmo";
        audioFondo.pause();
      } else {
        audioSecreto.pause();
        document.getElementById("music-status").textContent = "▶️ Reproducir ritmo";
      }
    };
  }

  document.getElementById("instrucciones-btn").onclick = () => {
    alert("¡Bienvenido a Pong Clicker!\n\n- Haz clic para ganar puntos\n- Compra mejoras en la tienda\n- Desbloquea Snake y Pong para bonus\n- Gana Fichas Pong al llegar a 10,000 pts (reinicia el juego, pero obtienes multiplicadores permanentes).\n\n- Pista de Secretos: clic en 'No toques' y 5 clics rápidos en el título...");
  };

  textoFinal.onclick = () => {
    textoFinal.textContent = "Pista: 5 clics rápidos en el título...";
    textoFinal.style.color = "red";
  };

  let clicksTitulo = 0;
  let timerTitulo;
  titulo.onclick = () => {
    if (hackUsado) return mostrarLogro("Hack ya usado");
    clicksTitulo++;
    clearTimeout(timerTitulo);
    timerTitulo = setTimeout(() => clicksTitulo = 0, 1000);
    if (clicksTitulo >= 5) {
      puntos += 10000;
      hackUsado = true;
      mostrarLogro("¡Hack secreto! +10.000 puntos");
      actualizar();
      guardar();
    }
  };

  // --- IMPLEMENTACIÓN DEL CHEAT SECRETO INFINITO (Tipo GTA) ---
  const CHEAT_CODE = "bigbang";
  let cheatIndex = 0;

  document.addEventListener("keydown", (e) => {
    const key = e.key.toLowerCase();
    
    // 1. Verificar si la tecla presionada coincide con el carácter actual en la secuencia
    if (key === CHEAT_CODE[cheatIndex]) {
        cheatIndex++;
    } else {
        // 2. Si la tecla no coincide, reiniciar la secuencia (a menos que sea la primera letra 'b')
        if (key === CHEAT_CODE[0]) {
            cheatIndex = 1;
        } else {
            cheatIndex = 0;
        }
    }

    // 3. Si la secuencia completa se ha introducido
    if (cheatIndex === CHEAT_CODE.length) {
        const puntosAntes = puntos;
        const fichasAntes = fichasPong;
        
        if (puntos === 0) puntos = 1; // Asegurar que 0 * 4 no sea 0
        puntos *= 4;
        
        // --- MODIFICACIÓN: Fichas Pong x 1000 ---
        if (fichasPong === 0) fichasPong = 1; // Prevenir 0 * 1000 = 0
        fichasPong *= 1000; 
        // ----------------------------------------
        
        mostrarLogro(`💥 BIGBANG: Pts x4 y Fichas Pong x1000! (+${Math.floor(fichasPong - fichasAntes).toLocaleString()} Fichas)`);
        
        actualizar();
        guardar();
        cheatIndex = 0; // Reiniciar el índice para que se pueda usar infinitamente
    }
  });
  // -------------------------------------------------------------

  // Inicio
  cargar();
  renderizarTienda();
  renderizarTiendaPrestigio();
  actualizar();
});